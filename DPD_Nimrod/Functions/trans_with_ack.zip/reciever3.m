
%%% There is problem with channel -  need check 

% revision 0.2 
% receiver with linear metrics
% we have simple track in here

tic
%start working
%sig_in=load(input_file)-adc_dc;
%sig_in_c=sig_in(:,1)'+j*sig_in(:,2)';

freq_est_bypass=0;
track_bypass=0;

sig_in_c=time_signal;
data_length=length(sig_in_c);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%           find fina_sync
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%ref_for_timing=sig_in_c(301:400)-sum(sig_in_c(301:400))/100;
ref_for_timing=load('fina_sync_series_for_EVM_prog.mat');
ref_for_timing=ref_for_timing.ref_for_timing;


a=filter(fliplr(conj(ref_for_timing)),1,sig_in_c); %correllation
[mxi,ind]=max(abs(a(1:end))); %find maximum of corellation
if (abs(a(ind))<1.2*abs(a(ind-128))), ind=ind-128; end %this is a patch to avoid some fina_sync misdetect

long_pre_start=ind-80; %this is the begining point of the long preamble
%long_pre_start=320+100+17;
fina_sinc=long_pre_start+166;
disp([' fina_sync found after ' num2str(fina_sinc) ' samples'])
disp('')
start=long_pre_start+64-16;
gi_droped=24-16;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%   frequency estimation and freq_fix_here ...
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (freq_est_bypass==0),
    
%freq estimation of the INA
freq_ina=40*10^3/32/2/pi*angle(sum((sig_in_c(long_pre_start+(-119:-88))).*conj(sig_in_c(long_pre_start+(-87:-56)))));
sig_in_c=sig_in_c.*exp(j*2*pi*freq_ina/40/10^3*(1:data_length)); %correction of this 

%freq estimation of the INA
freq_fina=40*10^3/128/2/pi*angle(sum((sig_in_c(long_pre_start+(16:182))).*conj(sig_in_c(long_pre_start+(144:310)))));
sig_in_c=sig_in_c.*exp(j*2*pi*freq_fina/40/10^3*(1:data_length));

freq_err=freq_ina+freq_fina;
disp([' frequency error estimated is ' num2str(freq_err) ' KHz'])
disp('')

else
disp([' frequency error estimation is bypassed '])
disp('')
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%     equlizer
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

chan_est=fft(sig_in_c(long_pre_start+32+gi_droped+(1:128)))/2+fft(sig_in_c(long_pre_start+32+gi_droped+128+(1:128)))/2;

chan_est_car=[chan_est(103:107) chan_est(109:121) chan_est(123:128) chan_est(2:7) chan_est(9:21) chan_est(23:27)];
chan_pilots=[chan_est([108,122,8,22])];

long_pre_in_freq=[1,1,-1,-1,1,1,-1,1,-1,1,1,1,1,1,1,-1,-1,1,1,-1,1,-1,1,1,1,1,0,1,-1,-1,1,1,-1,1,-1,1,-1,-1,-1,-1,-1,1,1,-1,-1,1,-1,1,-1,1,1,1,1];
lazy=[long_pre_in_freq(27:53) zeros(1,128-53) long_pre_in_freq(1:26)];

long_pre_data_carriers=[lazy(103:107) lazy(109:121) lazy(123:128) lazy(2:7) lazy(9:21) lazy(23:27)];
long_pre_pilots=[lazy([108,122,8,22])];

equ=1./chan_est_car.*long_pre_data_carriers;
equ_pilots=1./chan_pilots.*long_pre_pilots;

% end equlizer - no ereasures yet

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%            PLCP procesing
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

plcp_time=sig_in_c(long_pre_start+320+gi_droped+(1:128));
plcp_freq=fft(plcp_time);
%we skip track in here

plcp_freq_relevant=[plcp_freq(103:107) plcp_freq(109:121) plcp_freq(123:128) plcp_freq(2:7) plcp_freq(9:21) plcp_freq(23:27)];

plcp_equlized=plcp_freq_relevant.*equ;

plcp_before_inter=real(plcp_equlized)./abs(equ.^2);
%de-interleaving the PLCP
perm2=3*mod(0:47,16)+floor((0:47)/16); %interleaving for BPSK

vit_input_metric=plcp_before_inter(1+perm2); %de-interleaving

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%             viterbi initialization
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
prev_state_if_we_had_0=mod(2*(0:63),64);
out_bits_if_we_had_0=mod([([dec2bin(0:63)-48 zeros(64,1)]*fliplr([1,1,0,1,1,0,1])') ...
        ([dec2bin(0:63)-48 zeros(64,1)]*fliplr([1,0,0,1,1,1,1])')],2);

prev_state_if_we_had_1=mod(2*(0:63),64)+1;

pre_stage=[1+prev_state_if_we_had_0' 1+prev_state_if_we_had_1' (out_bits_if_we_had_0-0.5)*2]; %this variable contain pointers
              %to both possible preceeding stages, and the output bits in the first case. in the second case we get 
              %the nigation of thouse bits.

trace_len=60; %length of the trace back
surviver=[zeros(64,trace_len-1) (0:63)']; %initialazing the survivor path
metric=[0; 10^9*ones(63,1)]'; %initialazing the metrics

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%          viterbi operation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
leng=24; %length of the PLCP

for n=0:leng-1,
    
[metric,i]=min([metric(pre_stage(:,1))'-pre_stage(:,3:4)*vit_input_metric(2*n+(1:2))', ...
               metric(pre_stage(:,2))'+pre_stage(:,3:4)*vit_input_metric(2*n+(1:2))']'); %add compare select
           
surviver(:)=[surviver(diag(pre_stage(:,i)),2:trace_len) (0:63)']; %updating the trelis
[tem,ind]=min(metric); %finding minimum survivor path
end

signal=floor(surviver(1,(trace_len-leng+1):trace_len)/32); %this is the decoded PLCP

r=signal(1:4); %getting the rate from the PLCP
tx_leng=signal(6:17)*(2.^(0:11)'); %getting the length from the PLCP

%%%%%%%%%%%%%%%%%%%%%%%%%%%%% computing rate dependant parameters
   switch r*2.^((0:3)')
   case [1,1,0,1]*2.^((0:3)'), 
            kmod=1; p_rate=1/2; nbpsc=1; ncbps=48; ndbps=24; rate=6;
   case [1,1,1,1]*2.^((0:3)'), 
            kmod=1; p_rate=3/4; nbpsc=1; ncbps=48; ndbps=36; rate=9;
   case [0,1,0,1]*2.^((0:3)'), 
            kmod=1/sqrt(2); p_rate=1/2; nbpsc=2; ncbps=96; ndbps=48; rate=12;
   case [0,1,1,1]*2.^((0:3)'), 
            kmod=1/sqrt(2); p_rate=3/4; nbpsc=2; ncbps=96; ndbps=72; rate=18;
   case [1,0,0,1]*2.^((0:3)'), 
            kmod=1/sqrt(10); p_rate=1/2; nbpsc=4; ncbps=192; ndbps=96; rate=24;
   case [1,0,1,1]*2.^((0:3)'), 
            kmod=1/sqrt(10); p_rate=3/4; nbpsc=4; ncbps=192; ndbps=144; rate=36;
   case [0,0,0,1]*2.^((0:3)'), 
            kmod=1/sqrt(42); p_rate=2/3; nbpsc=6; ncbps=288; ndbps=192; rate=48;
   case [0,0,1,1]*2.^((0:3)'), 
            kmod=1/sqrt(42); p_rate=3/4; nbpsc=6; ncbps=288; ndbps=216; rate=54;
        
        otherwise, 
            disp([' rate was misdeteced, halting'])
            return
        end
disp([' rate is ' num2str(rate) ' Mbit/s'])
disp([' length is ' num2str(tx_leng) ' bytes'])

disp('')

  
%%%%%%%%%%%%%%%%%%%%%%%% computing length dependant parameters
 
nsym=ceil((16+8*tx_leng+6)/ndbps); %number of data symbols in the frame
ndata=nsym*ndbps; %number of overall bits (including padding)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% end of PLCP processing  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% reception of regular data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% arranging the data
time_dom_signal=reshape(sig_in_c(long_pre_start+480+(1:160*nsym)),160,nsym);

%%%%  remove guard interval

time_dom_signal=time_dom_signal(gi_droped+(1:128),:);

%% pass through FFT
freq_dom_signal=fft(time_dom_signal);


relevant_data=[freq_dom_signal(103:107,:); freq_dom_signal(109:121,:); freq_dom_signal(123:128,:); ...
               freq_dom_signal(2:7,:); freq_dom_signal(9:21,:); freq_dom_signal(23:27,:)];

equlized_data=relevant_data.*kron(equ.',ones(1,nsym));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         track
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%creating long (constant) scrambler series
scram_series=abs(rem(filter(0,[1,0,0,0,1,0,0,1],zeros(1,127),[1,1,1,1,1,1,1]),2));
scram_series=[scram_series scram_series scram_series scram_series scram_series scram_series];
scram_series=[scram_series scram_series scram_series scram_series scram_series scram_series];
scram_series=[scram_series scram_series scram_series scram_series scram_series scram_series]; 

pilots_vector=-2*(scram_series(132+(1:(nsym)))-0.5)';


pilots_in_reception=[freq_dom_signal(108,:); freq_dom_signal(122,:);  freq_dom_signal(8,:); -freq_dom_signal(22,:);];
track_phase_corection=angle(sum(pilots_in_reception.*kron(equ_pilots.',ones(1,nsym))).*pilots_vector.');
tracked_equlized_data_freq=equlized_data.*kron(ones(48,1),exp(-j*track_phase_corection));

track_timing_vect=sum(angle(pilots_in_reception.*kron((equ_pilots).',ones(1,nsym)).*kron(pilots_vector,ones(1,4)).').*kron(ones(nsym,1),[-1,-1,1,1]).')/8/7;
carrier_index=[-26:26]; carrier_index([-21,-7,0,7,21]+27)=[];
track_time_compe=exp(-j*kron(ones(48,1),track_timing_vect).*kron(carrier_index.',ones(1,nsym)));
tracked_equlized_data=tracked_equlized_data_freq.*track_time_compe;


if (track_bypass==1)
    tracked_equlized_data=equlized_data;
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         de-mapping
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
k=0.3; 
r=real(tracked_equlized_data/kmod);
im=imag(tracked_equlized_data/kmod);

de_mapped_data=zeros(ncbps,nsym);

switch nbpsc %eval('nbpsc')
case 1 %BPSK
    de_mapped_data=r./kron(abs(equ.^2).',ones(1,nsym));
case 2 %QPSK
    de_mapped_data(1:2:ncbps,:)=r./kron(abs(equ.^2).',ones(1,nsym));
    de_mapped_data(2:2:ncbps,:)=im./kron(abs(equ.^2).',ones(1,nsym));
    
case 4 %QAM16
    msb_met_r=r./kron(abs(equ.^2).',ones(1,nsym)); %log((exp(-(r-1).^2/k)+exp(-(r-3).^2/k))./(exp(-(r+1).^2/k)+exp(-(r+3).^2/k)))./kron(abs(equ.^2).',ones(1,nsym));
    lsb_met_r=(2-abs(r))./kron(abs(equ.^2).',ones(1,nsym)); %log((exp(-(r+1).^2/k)+exp(-(r-1).^2/k))./(exp(-(r-3).^2/k)+exp(-(r+3).^2/k)))./kron(abs(equ.^2).',ones(1,nsym));
    
    msb_met_im=im./kron(abs(equ.^2).',ones(1,nsym)); %log((exp(-(im-1).^2/k)+exp(-(r-3).^2/k))./(exp(-(im+1).^2/k)+exp(-(im+3).^2/k)))./kron(abs(equ.^2).',ones(1,nsym));
    lsb_met_im=(2-abs(im))./kron(abs(equ.^2).',ones(1,nsym)); %log((exp(-(im+1).^2/k)+exp(-(r-1).^2/k))./(exp(-(im-3).^2/k)+exp(-(im+3).^2/k)))./kron(abs(equ.^2).',ones(1,nsym));
    
    de_mapped_data(1:4:ncbps,:)=msb_met_r;
    de_mapped_data(2:4:ncbps,:)=lsb_met_r;
    de_mapped_data(3:4:ncbps,:)=msb_met_im;
    de_mapped_data(4:4:ncbps,:)=lsb_met_im;

    
case 6 %QAM64
    msb_met_r=r./kron(abs(equ.^2).',ones(1,nsym)); %log((exp(-(r-1).^2/k)+exp(-(r-3).^2/k)+exp(-(r-5).^2/k)+exp(-(r-7).^2/k))./(exp(-(r+1).^2/k)+exp(-(r+3).^2/k)+exp(-(r+5).^2/k)+exp(-(r+7).^2/k)))./kron(abs(equ.^2).',ones(1,nsym));
    mid_met_r=(4-abs(r))./kron(abs(equ.^2).',ones(1,nsym)); %log((exp(-(r-1).^2/k)+exp(-(r-3).^2/k)+exp(-(r+1).^2/k)+exp(-(r+3).^2/k))./(exp(-(r+7).^2/k)+exp(-(r+5).^2/k)+exp(-(r-5).^2/k)+exp(-(r-7).^2/k)))./kron(abs(equ.^2).',ones(1,nsym));
    lsb_met_r=(2-abs(4-abs(r)))./kron(abs(equ.^2).',ones(1,nsym)); %log((exp(-(r+5).^2/k)+exp(-(r+3).^2/k)+exp(-(r-5).^2/k)+exp(-(r-3).^2/k))./(exp(-(r+1).^2/k)+exp(-(r+7).^2/k)+exp(-(r-1).^2/k)+exp(-(r-7).^2/k)))./kron(abs(equ.^2).',ones(1,nsym));
    
    msb_met_im=im./kron(abs(equ.^2).',ones(1,nsym)); %log((exp(-(im-1).^2/k)+exp(-(im-3).^2/k)+exp(-(im-5).^2/k)+exp(-(im-7).^2/k))./(exp(-(im+1).^2/k)+exp(-(im+3).^2/k)+exp(-(im+5).^2/k)+exp(-(im+7).^2/k)))./kron(abs(equ.^2).',ones(1,nsym));
    mid_met_im=(4-abs(im))./kron(abs(equ.^2).',ones(1,nsym)); %log((exp(-(im-1).^2/k)+exp(-(im-3).^2/k)+exp(-(im+1).^2/k)+exp(-(im+3).^2/k))./(exp(-(im+7).^2/k)+exp(-(im+5).^2/k)+exp(-(im-5).^2/k)+exp(-(im-7).^2/k)))./kron(abs(equ.^2).',ones(1,nsym));
    lsb_met_im=(2-abs(4-abs(im)))./kron(abs(equ.^2).',ones(1,nsym)); %log((exp(-(im+5).^2/k)+exp(-(im+3).^2/k)+exp(-(im-5).^2/k)+exp(-(im-3).^2/k))./(exp(-(im+1).^2/k)+exp(-(im+7).^2/k)+exp(-(im-1).^2/k)+exp(-(im-7).^2/k)))./kron(abs(equ.^2).',ones(1,nsym));

    de_mapped_data(1:6:ncbps,:)=msb_met_r;
    de_mapped_data(2:6:ncbps,:)=mid_met_r;
    de_mapped_data(3:6:ncbps,:)=lsb_met_r;
    de_mapped_data(4:6:ncbps,:)=msb_met_im;
    de_mapped_data(5:6:ncbps,:)=mid_met_im;
    de_mapped_data(6:6:ncbps,:)=lsb_met_im;
otherwise
    0
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%     de-interleaver
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%interleaver formula
s=max(nbpsc/2,1);
perm1=ncbps/16*mod(0:(ncbps-1),16)+floor((0:(ncbps-1))/16);
perm2=s*floor((perm1)/s)+mod((perm1)+ncbps-floor(16*(perm1)/ncbps),s);

de_interleaved_data=de_mapped_data(1+perm2,:);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%      de-pancture
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

de_interleaved_stream=de_interleaved_data(:);
a=zeros(1,ndata);
b=zeros(1,ndata);

switch p_rate %eval('p_rate')
case 1/2
    vit_input_metric=de_interleaved_stream.';
    
case 3/4
    a(1:3:ndata)=de_interleaved_stream(1:4:4/3*ndata);
    a(2:3:ndata)=de_interleaved_stream(3:4:4/3*ndata);
    b(1:3:ndata)=de_interleaved_stream(2:4:4/3*ndata);
    b(3:3:ndata)=de_interleaved_stream(4:4:4/3*ndata);
    
    vit_input_metric=reshape([a;b],1,2*ndata);

case 2/3
    a(1:2:ndata)=de_interleaved_stream(1:3:3/2*ndata);
    a(2:2:ndata)=de_interleaved_stream(3:3:3/2*ndata); 
    b(1:2:ndata)=de_interleaved_stream(2:3:3/2*ndata);
    
    vit_input_metric=reshape([a;b],1,2*ndata);

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%      and now for some viterbi decoding
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

trace_len=60; %length of the trace back
surviver=[zeros(64,trace_len-1) (0:63)']; %initialazing the survivor path

metric=[0; 10^9*ones(63,1)]'; %initialazing the metrics
out_bits=zeros(1,leng); %initialazing the output bits vector
leng=tx_leng*8+22; %this is the length of the data in bits, including 16 preceeding zeros and 6 tail bits
for n=0:leng-1,
    
[metric,i]=min([metric(pre_stage(:,1))'-pre_stage(:,3:4)*vit_input_metric(2*n+(1:2))', ...
               metric(pre_stage(:,2))'+pre_stage(:,3:4)*vit_input_metric(2*n+(1:2))']'); %add compare select
           
surviver(:)=[surviver(diag(pre_stage(:,i)),2:trace_len) (0:63)']; %updating the trelis
[tem,ind]=min(metric); %finding minimum survivor path
out_bits(1+n)=surviver(ind,1); %bit to get out of the trelis next step.
end

if (trace_len >=leng)
    out_bits=floor(surviver(1,(trace_len-leng+1):trace_len)/32);
else
out_bits=floor([out_bits(trace_len:leng) surviver(ind,2:trace_len)]/32);
end



%%%%%%%%%%%%%%%%%%%%%%%
%%%%% de-scrambling
%%%%%%%%%%%%%%%%%%%%%%%%

scrambler_seed=out_bits(1:7);
% the scramling series itself was created above (in the track)
[m,i]=max(conv(2*(fliplr(scrambler_seed)-0.5),(scram_series-0.5)*2)); %finding the portion of the series that corespond to the seed
decoded_data1=xor(out_bits(7+(1:tx_leng*8+15)),scram_series(i+(1:tx_leng*8+15))); %xoring with the data

decoded_data=decoded_data1(9+(1:8*tx_leng)); %taking out the relevant data bits
decoded_data_decimal=reshape(decoded_data,8,tx_leng).'*2.^(0:7).';
decoded_data_HEX=dec2hex(decoded_data_decimal);
sum(xor(decoded_data,dino_data)) %ber
%toc