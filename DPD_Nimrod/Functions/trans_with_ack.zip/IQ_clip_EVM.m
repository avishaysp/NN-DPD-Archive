%%  Check I,Q clip impact on OFDM signal 

trans_with_ack;
Sig=time_signal/std(time_signal);
I=imag(Sig);
Q=real(Sig);
ClipIQ=abs(I)+abs(Q);
sig_phase=angle(Sig);

evm_db_vec1=[];
evm_db_vec2=[];
evm_db_vec3=[];
evm_db_vec4=[];
evm_db_vec5=[];

Nvec=2:0.1:3;
Nvec=1;
for Ns=Nvec,
Qclip=Q;
Iclip=I;
Sig_clip_abs=abs(Sig);
%X=find (ClipIQ>Ns);


%% Diamond Clip
X=find (ClipIQ>Ns*sqrt(2)); %% mutiplied to compare to square lenght 
Qclip(X)=Ns*sqrt(2)./(1+abs(tan(sig_phase(X))));
Iclip(X)=Qclip(X).*tan(sig_phase(X));
Sig_clip_abs_IQ=abs(Qclip+j*Iclip);
Sig_clip=Sig_clip_abs_IQ.*exp(j*sig_phase);

%%% Circular Clip
Y=find(Sig_clip_abs>Ns);
Sig_clip_abs(Y)=Ns;
Sig_clip2=Sig_clip_abs.*exp(j*sig_phase);

%%% Square clip
Qclip=Q;
Iclip=I;
Zq1=find(Q>Ns);
Zq2=find(Q<-Ns);
Qclip(Zq1)=Ns;
Qclip(Zq2)=-Ns;
Zi1=find(I>Ns);
Zi2=find(I<-Ns);
Iclip(Zi1)=Ns;
Iclip(Zi2)=-Ns;
Sig_clip3=Qclip+j*Iclip;

%% preserve angle 
Zq=find((abs(Q)>Ns)&(abs(Q)>=abs(I)));
Zi=find((abs(I)>Ns)&(abs(I)>=abs(Q)));
Qclip=Q;
Iclip=I;
Qclip(Zq)=Ns;
Iclip(Zq)=Qclip(Zq).*tan(sig_phase(Zq));
Iclip(Zi)=Ns;
Qclip(Zi)=Iclip(Zi)./tan(sig_phase(Zi));
Sig_clip_abs_IQ3=abs(Qclip+j*Iclip); 
Sig_clip4=Sig_clip_abs_IQ3.*exp(j*sig_phase);





time_signal=Sig_clip;
EVM_only
evm_db_vec1=[evm_db_vec1 evm_db]; %% diamond clip

time_signal=Sig_clip2;
EVM_only
evm_db_vec2=[evm_db_vec2 evm_db];

time_signal=Sig_clip3;
EVM_only
evm_db_vec3=[evm_db_vec3 evm_db];

time_signal=Sig_clip4;
EVM_only
evm_db_vec4=[evm_db_vec4 evm_db];

end
PAPR=db(Nvec);
figure(1),plot(PAPR,evm_db_vec1,PAPR,evm_db_vec2,PAPR,evm_db_vec3,PAPR,evm_db_vec4);
grid
title('EVM vs clip diamond square and circular');
xlabel('PAPR [dB]')
ylabel('EVM [dB]')
legend('diamond','circular','square','square2')

figure(2),plot(Sig_clip);
figure(3),plot(Sig_clip2);
figure(4),plot(Sig_clip3);
figure(5),plot(Sig_clip4);



%%% show EVM under rotation clip (show circular symmetry )
ang_vec=0:5:90;  %% In deg
for ang_rot=ang_vec,
    Sig_rot=Sig*exp(j*ang_rot*pi/180);
    sig_phase=angle(Sig_rot);
 Ns=2.2;
I=imag(Sig_rot);
Q=real(Sig_rot);
Sig_clip_abs=abs(Sig_rot);   
    %% Diamond Clip
Qclip=Q;
Iclip=I;
ClipIQ=abs(I)+abs(Q);
X=find (ClipIQ>Ns*sqrt(2)); %% mutiplied to compare to square lenght 
Qclip(X)=Ns*sqrt(2)./(1+abs(tan(sig_phase(X))));
Iclip(X)=Qclip(X).*tan(sig_phase(X));
Sig_clip_abs_IQ=abs(Qclip+j*Iclip);
Sig_clip=Sig_clip_abs_IQ.*exp(j*sig_phase);

% %%% Circular Clip
% Y=find(Sig_clip_abs>Ns);
% Sig_clip_abs(Y)=Ns;
% Sig_clip=Sig_clip_abs.*exp(j*sig_phase);

time_signal=Sig_clip;
EVM_only
evm_db_vec5=[evm_db_vec5 evm_db]; %% diamond clip
end
figure(6),plot(ang_vec,evm_db_vec5);
grid
title('EVM vs rotation diamond clip');
xlabel('phase rotation [deg]')
ylabel('EVM [dB]')
%legend('diamond','circular','square','square2')
