
reciever2

%%%%%% additions for EVM measurments

switch nbpsc %switch on the different modluations
    
case 1
    hard_decision=sign(round((1/(kmod)*tracked_equlized_data-1)/2)*2+1);
    
case 2
    hard_decision=round((1/(kmod)*tracked_equlized_data-1-j)/2)*2+1+j;
    errors_up=find(real(hard_decision)>1);
    hard_decision(errors_up)=1+j*imag(hard_decision(errors_up));
    errors_down=find(real(hard_decision)<-1);
    hard_decision(errors_down)=-1+j*imag(hard_decision(errors_down));

    errors_up=find(imag(hard_decision)>1);
    hard_decision(errors_up)=j+real(hard_decision(errors_up));
    errors_down=find(imag(hard_decision)<-1);
    hard_decision(errors_down)=-j+real(hard_decision(errors_down));   
    
case 4
   hard_decision=round((1/(kmod)*tracked_equlized_data-1-j)/2)*2+1+j;
   
    errors_up=find(real(hard_decision)>3);
    hard_decision(errors_up)=3+j*imag(hard_decision(errors_up));
    errors_down=find(real(hard_decision)<-3);
    hard_decision(errors_down)=-3+j*imag(hard_decision(errors_down));

    errors_up=find(imag(hard_decision)>3);
    hard_decision(errors_up)=j*3+real(hard_decision(errors_up));
    errors_down=find(imag(hard_decision)<-3);
    hard_decision(errors_down)=-j*3+real(hard_decision(errors_down));   

case 6
   hard_decision=round((1/(kmod)*tracked_equlized_data-1-j)/2)*2+1+j;
       
   errors_up=find(real(hard_decision)>7);
    hard_decision(errors_up)=7+j*imag(hard_decision(errors_up));
    errors_down=find(real(hard_decision)<-7);
    hard_decision(errors_down)=-7+j*imag(hard_decision(errors_down));

    errors_up=find(imag(hard_decision)>7);
    hard_decision(errors_up)=j*7+real(hard_decision(errors_up));
    errors_down=find(imag(hard_decision)<-7);
    hard_decision(errors_down)=-j*7+real(hard_decision(errors_down));   

end


% figure(1);
% %Constellatiom MAP
% plot(1/kmod*tracked_equlized_data,'.')
% 
evm_is=sum(sum(abs(1/(kmod)*tracked_equlized_data-hard_decision).^2))/48/nsym*kmod^2;
evm_db=10*log10(evm_is);
% disp([' EVM is ' num2str(evm_db) ' dB'])
% disp(' ')
% title(['@ EVM is ' num2str(evm_db) ' dB']);
% 
% 
% %%%%%%% pulse response
% figure(2);
% plot(abs(ifft(chan_est.*lazy)))
% title('channel pulse response')
% 
% figure(3);
% plot(20*log10(abs(fftshift(chan_est.*lazy))))
% title('channel response')
% 
% figure(4)
% plot(unwrap(track_phase_corection))
% ylabel('PHASE (radians)');
% xlabel('Symbols');
% 
% figure(5)
% plot(1/kmod*sum(abs(tracked_equlized_data).^2))
% title('average symbol power')
% 
% figure(6)
% plot(10*log10((sum(abs(1/(kmod)*tracked_equlized_data-hard_decision).'.^2))/nsym*kmod^2))
% title('EVM as function of the carriers');
% xlabel('the 48 carriers');
% 
% figure(7)
% plot(10*log10((sum(abs(1/(kmod)*tracked_equlized_data-hard_decision).^2))/48*kmod^2))
% title('EVM vs.time');
% xlabel('the 48 carriers symbols');
% 
% figure(8)
% plot(sum(abs(reshape(time_signal(1:1200),40,1200/40))))
% xlabel('time in micro seconds');
% title('amplitude vs. time');
% 
% 
% figure(9); 
% plot(abs(sum(pilots_in_reception.*kron(equ_pilots.',ones(1,nsym))).*pilots_vector.'))
% xlabel('symbol index');
% title('pilots amplitude vs. time');
% 
% figure(10); 
% plot(10*log10((sum(abs(1/(kmod)*tracked_equlized_data-hard_decision).'.^2))/nsym*kmod^2)-20*log10(abs(equ)))
% title('EVM as function of the carriers BEFORE equalizer');
% 
% xlabel('the 48 carriers');
% 
% figure(11); 
% plot(20*log10(abs(1./equ)))
% title('channel shape');
% xlabel('the 48 carriers');
