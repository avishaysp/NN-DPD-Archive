tic

num_of_packets=1;
packet_data_length=2000;
silence_period=56; %microseconds

rate=54;
multi_frame=zeros(1,40*silence_period);
%input_file_bytes='p:\temp\100bytes_broadcast.txt' %data input file.  should be in decimal.

%dino_header=[0x08; 0x02 0x00; 0x00; 0xFF; 0xFF; 0xFF; 0xFF; 0xFF; 0xFF; 0x00; 0x00; 0x00; 0x00; 0x00; 0x00; 0x00; 0x00; 0x00; 0x00; 0x00; 0x00; 0x00; 0x00;];
%brodcast data
%dino_header=[08; 00; 00; 00; 255; 255; 255; 255; 255; 255; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0;];

dino_header=[08; 00; 00; 00; 00; 17; 17; 17; 17; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0;];

%dino_header_bits=reshape(fliplr(dec2bin(dino_header)-48)',1,8*24);
%for rate=6, %rate=[6,9,12,18,24,36,48,54]
%for rate=[6,9,12,18,24,36,48,54]

    multi_frame=zeros(1,40*silence_period);
    

for kk=1:num_of_packets

scrambler_seed=round(rand(1,7));
input_data_bytes=[dino_header; kk*ones(packet_data_length,1)];
% fid = fopen(input_file_bytes); input_data_bytes=fscanf(fid,'%x',[1 inf]).'; fclose(fid);
% length_bytes=length(input_data_bytes);

%dino_data=round(rand(1,length_bytes*8));
%input_data_bytes=load(input_file_bytes); %data input file.  should be in decimal.
dino_data=reshape(fliplr(dec2bin(input_data_bytes,8)-48)',1,8*length(input_data_bytes)); %translating data to bits

%%% adding crc to the data+header bits
for_crc_step_1=[ not(dino_data(1:32)) dino_data(33:end) zeros(1,32)];
crc_poly=([1,1,1,0,1,1,0,1,1,0,1,1,1,0,0,0,1,0,0,0,0,0,1,1,0,0,1,0,0,0,0,0,1]);
[q,for_crc_step_2] = gfdeconv(fliplr(for_crc_step_1),crc_poly);
crc_bits=not([ for_crc_step_2  zeros(1,32-length(for_crc_step_2))]);
%dino_data=[dino_data(1:992) fliplr(crc_bits(1:8)) fliplr(crc_bits(9:16)) fliplr(crc_bits(17:24)) fliplr(crc_bits(25:32))];
dino_data=[dino_data fliplr(crc_bits)];
% dont forget to set the correct length of the bytes or bits

%%%%%%%%%%%%%%%%%%%%%%%%%
% creating the preamble
%%%%%%%%%%%%%%%%%%%%%%%%%
xshort=sqrt(13/6)*[0,0,1+j,0,0,0,-1-j,0,0,0,1+j,0,0,0,-1-j,0,0,0,-1-j,0,0,0,1+j,0,0,0,0,0,0,0,-1-j,0,0,0,-1-j,0,0,0,1+j,0,0,0,1+j,0,0,0,1+j,0,0,0,1+j,0,0];
sigshort=ifft([0 xshort(28:53) zeros(1,128-53) xshort(1:26)]);
xpreamble=[1,1,-1,-1,1,1,-1,1,-1,1,1,1,1,1,1,-1,-1,1,1,-1,1,-1,1,1,1,1,0,1,-1,-1,1,1,-1,1,-1,1,-1,-1,-1,-1,-1,1,1,-1,-1,1,-1,1,-1,1,1,1,1];
siglong=ifft([xpreamble(27:53) zeros(1,128-53) xpreamble(1:26)]);

preamble=[sigshort sigshort sigshort(1:64) siglong(65:128) siglong siglong];

%%%%%%%%%%%%%%%%%%%%%%%%%

   switch eval('rate')
   case 6, 
            kmod=1; p_rate=1/2; nbpsc=1; ncbps=48; ndbps=24; r=[1,1,0,1];
   case 9, 
            kmod=1; p_rate=3/4; nbpsc=1; ncbps=48; ndbps=36; r=[1,1,1,1];
   case 12, 
            kmod=1/sqrt(2); p_rate=1/2; nbpsc=2; ncbps=96; ndbps=48; r=[0,1,0,1];
   case 18, 
            kmod=1/sqrt(2); p_rate=3/4; nbpsc=2; ncbps=96; ndbps=72; r=[0,1,1,1];
   case 24, 
            kmod=1/sqrt(10); p_rate=1/2; nbpsc=4; ncbps=192; ndbps=96; r=[1,0,0,1];
   case 36, 
            kmod=1/sqrt(10); p_rate=3/4; nbpsc=4; ncbps=192; ndbps=144; r=[1,0,1,1];
   case 48, 
            kmod=1/sqrt(42); p_rate=2/3; nbpsc=6; ncbps=288; ndbps=192; r=[0,0,0,1];
   case 54, 
            kmod=1/sqrt(42); p_rate=3/4; nbpsc=6; ncbps=288; ndbps=216; r=[0,0,1,1];
        
        otherwise, 
            0
        end
       
data_length_bits=length(dino_data);
nsym=ceil((16+data_length_bits+6)/ndbps); %number of data symbols in the frame
ndata=nsym*ndbps; %number of overall bits (including padding)
data=[zeros(1,16) dino_data]; %this is the scrambler initialization +service +data to be sent

% paddind data with zeros
t_data=zeros(1,ndata);
t_data(1:(data_length_bits+16))=data;
data=t_data;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% creating the PLCP header
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tx_length_vec=dec2bin(data_length_bits/8)-48;
tx_length_vec1=[zeros(1,12-length(tx_length_vec)) tx_length_vec];
signal=[r 0 fliplr(tx_length_vec1)]; %rate, reserved bit, and length
signal=[signal rem(sum(signal),2) zeros(1,6)]; %parity bits and SIGNAL tail

%conv-encoding of the PLCP header
a=abs(rem(filter(fliplr([1,1,0,1,1,0,1]),1,signal),2));
b=abs(rem(filter(fliplr([1,0,0,1,1,1,1]),1,signal),2));

yp=reshape([a;b],1,48); %no puncturing for PLCP

%interleaving the PLCP
perm2=3*mod(0:47,16)+floor((0:47)/16); %interleaving for BPSK
inter_plcp(1+perm2)=yp;

%% mapping the PLCP header
mapped_plcp=(inter_plcp-0.5)*2;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%
% returning to the data
%%%%%%%%%%%%%%%%%%%%%%%%%%

%scrambler

%creating long (constant) scrambler series
scram_series=abs(rem(filter(0,[1,0,0,0,1,0,0,1],zeros(1,127),[1,1,1,1,1,1,1]),2));
scram_series=[scram_series scram_series scram_series scram_series scram_series scram_series];
scram_series=[scram_series scram_series scram_series scram_series scram_series scram_series];
scram_series=[scram_series scram_series scram_series scram_series scram_series scram_series]; 

[m,i]=max(conv(2*(fliplr(scrambler_seed)-0.5),(scram_series-0.5)*2)); %finding the portion of the series that corespond to the seed
s_data=xor(data,scram_series(i+(1:ndata))); %xoring with the data

s_data(data_length_bits+(17:22))=zeros(1,6); %%%% insert 6 tail bits in here

%conv-encoding
a=abs(rem(filter(fliplr([1,1,0,1,1,0,1]),1,s_data),2));
b=abs(rem(filter(fliplr([1,0,0,1,1,1,1]),1,s_data),2));

%puncturing
switch p_rate %eval('p_rate')
case 1/2
    y=zeros(1,2*ndata);
    y=reshape([a;b],1,2*ndata);
    
case 3/4
    y=zeros(1,4/3*ndata);
    y(1:4:4/3*ndata)=a(1:3:ndata);
    y(3:4:4/3*ndata)=a(2:3:ndata);
    y(2:4:4/3*ndata)=b(1:3:ndata);
    y(4:4:4/3*ndata)=b(3:3:ndata);

case 2/3
    y=zeros(1,3/2*ndata);
    y(1:3:3/2*ndata)=a(1:2:ndata);
    y(3:3:3/2*ndata)=a(2:2:ndata); 
    y(2:3:3/2*ndata)=b(1:2:ndata);
end

%interleaving
s=max(nbpsc/2,1);
perm1=ncbps/16*mod(0:(ncbps-1),16)+floor((0:(ncbps-1))/16);
perm2=s*floor((perm1)/s)+mod((perm1)+ncbps-floor(16*(perm1)/ncbps),s);

data=reshape(y,ncbps,nsym)';
clear inter_data;
inter_data(:,1+perm2)=data;


%mapping

half_maped=zeros(size(inter_data));

switch nbpsc %eval('nbpsc')
case 1 %BPSK
    half_maped=(inter_data-0.5)*2;
case 2 %QPSK
    half_maped=(inter_data(:,1:2:ncbps)-0.5)*2+j*(inter_data(:,2:2:ncbps)-0.5)*2;
case 4 %QAM16
    half_maped=(2-(inter_data(:,2:4:ncbps)-0.5)*2).*(inter_data(:,1:4:ncbps)-0.5)*2+...
    j*(2-(inter_data(:,4:4:ncbps)-0.5)*2).*(inter_data(:,3:4:ncbps)-0.5)*2;
case 6 %QAM64
    half_maped=(4-(2-(inter_data(:,3:6:ncbps)-0.5)*2).*(inter_data(:,2:6:ncbps)-0.5)*2).*(inter_data(:,1:6:ncbps)-0.5)*2+...
             j*(4-(2-(inter_data(:,6:6:ncbps)-0.5)*2).*(inter_data(:,5:6:ncbps)-0.5)*2).*(inter_data(:,4:6:ncbps)-0.5)*2;
otherwise
    0
end

%normalizing and adding the PLCP

mapped=[mapped_plcp ; half_maped*kmod];


%pilots vectors

%pilots_vector=reshape(-2*(scram_series(131+(1:4*(nsym+1)))-0.5),4,nsym+1)';
pilots_vector=-2*(scram_series(131+(1:(nsym+1)))-0.5)';

%aranging the carriers and inserting the pilots 
tofft=[zeros(nsym+1,1) mapped(:,25:30) pilots_vector mapped(:,31:43) -pilots_vector mapped(:,44:48) zeros(nsym+1,75) ...
        mapped(:,1:5) pilots_vector mapped(:,6:18) pilots_vector mapped(:,19:24)];

time_dom=ifft(tofft.').';
with_gi=[time_dom(:,97:128) time_dom].';

time_signal=[preamble with_gi(:).'];

multi_frame=[multi_frame time_signal zeros(1,40*silence_period)];

end

toc

% fid = fopen (['multi_frame_with_ack_rate_' num2str(rate) '_' num2str(packet_data_length) '_bytes.txt'], 'w');
% fprintf(fid,'%f %f\r\n', [real(multi_frame).' imag(multi_frame).'].');
% fclose(fid);
% 
% 
% chan_6 =[  0.2325 + 0.0454i   0.4846 + 0.1690i   0.4413 + 0.3269i   0.1232 + 0.4179i  -0.1069 + 0.3482i ...
%            -0.0462 + 0.1464i   0.0972 - 0.0290i   0.0702 - 0.0540i  -0.0565 + 0.0192i  -0.0704 + 0.0495i ...
%                  0             0.0524 - 0.0329i        0 ]/1.5;            
% 
% time_signal_chan=filter(chan_6,1,multi_frame);
% 
% fid = fopen (['multi_frame_with_ack_rate_' num2str(rate) '_' num2str(packet_data_length) '_bytes_chan_6.txt'], 'w');
% fprintf(fid,'%f %f\r\n', [real(time_signal_chan).' imag(time_signal_chan).'].');
% fclose(fid);
% end
% 
% fid = fopen ('rate_12_100_bytes_broadcast_1.txt', 'w');
% fprintf(fid,'%f %f\r\n', [real(time_signal).' imag(time_signal).'].');
% fclose(fid);
